# LP Memecoin Class — Landing Page
Next.js + Tailwind + framer-motion + recharts

## Local Dev
```bash
npm install
npm run dev
```
Open http://localhost:3000

## Deploy to Vercel
1. Create a new Vercel project and import this repo.
2. Framework preset: **Next.js** (auto-detected).
3. Build command: `next build` (default), Output dir: `.next` (default).
4. After deploy, open your domain.
